<?php ?>
<ul class="list-unstyled">
    <?php print $content; ?>
</ul>
