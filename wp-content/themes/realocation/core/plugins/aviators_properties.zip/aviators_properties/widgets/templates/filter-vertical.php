<?php $renderer->renderStart(); ?>
<?php $renderer->render(); ?>
<?php $renderer->renderClose(); ?>