<div class="wrap">
	<div class="hydra-title">
		<div class="hydra-logo">
			<img src="<?php echo $image_url ?>" alt="<?php echo $title; ?>">
		</div><!-- /.hydra-logo -->

		<h2><?php echo $title; ?></h2>
	</div><!-- /.hydra-title -->
</div><!-- /.wrap -->