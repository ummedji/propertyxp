# WordPress MySQL database migration
#
# Generated: Saturday 18. February 2017 14:14 UTC
# Hostname: 192.168.1.245
# Database: `property_proxp_test`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_aiowps_events`
#

DROP TABLE IF EXISTS `wp_aiowps_events`;


#
# Table structure of table `wp_aiowps_events`
#

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) NOT NULL DEFAULT '',
  `username` varchar(150) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) DEFAULT NULL,
  `referer_info` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `event_data` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_aiowps_events`
#

#
# End of data contents of table `wp_aiowps_events`
# --------------------------------------------------------

